// === Global error reporter ===
window.onerror = function (msg, src, line, col, err) {
  const hud = document.getElementById("hud");
  if (hud) {
    hud.innerHTML =
      '<span style="color:#f66">Error</span>: ' +
      msg +
      " @" +
      (src || "") +
      ":" +
      line +
      ":" +
      col;
  }
  console.error(msg, src, line, col, err);
};

// ===== Canvas & Temp =====
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const tempCanvas = document.createElement("canvas");
const tctx = tempCanvas.getContext("2d");

// Halftone blob 파이프라인용 보조 캔버스
const accumCanvas = document.createElement("canvas"); // 점 누적
const actx = accumCanvas.getContext("2d");
const blurCanvas = document.createElement("canvas"); // 블러 결과
const bctx = blurCanvas.getContext("2d");

// ===== Controls =====
const loader = document.getElementById("imageLoader");
const modeMosaic = document.getElementById("modeMosaic");
const modeHalftone = document.getElementById("modeHalftone");
const modePattern = document.getElementById("modePattern");
const blockSlider = document.getElementById("blockSize");
const imgSlider = document.getElementById("imgScale");
const shapeSlider = document.getElementById("shapeSmooth");
const strokeToggle = document.getElementById("strokeToggle");
const rotSlider = document.getElementById("rotationControl");
const trailSlider = document.getElementById("trailLength");
const colorBlurToggle = document.getElementById("colorBlurToggle");
const gpuToggle = document.getElementById("gpuToggle");
const htInkEl = document.getElementById("htInkColor");
const ptInkEl = document.getElementById("ptInkColor");

// ▼ 여기 추가
if (htInkEl) {
  htInkEl.addEventListener("input", () => draw());
}
if (ptInkEl) {
  ptInkEl.addEventListener("input", () => {
    generatePatterns();
    draw();
  });
}

// ===== Labels =====
const blockValue = document.getElementById("blockValue");
const scaleValue = document.getElementById("scaleValue");
const shapeValue = document.getElementById("shapeValue");
const rotationValue = document.getElementById("rotationValue");
const trailValue = document.getElementById("trailLengthValue");

// ===== State =====
let img = new Image();
let video = null;
let isVideo = false;
let currAngle = 0;
let offsetX = 0,
  offsetY = 0;
let isDragging = false,
  dragStartX = 0,
  dragStartY = 0,
  origOffsetX = 0,
  origOffsetY = 0;
const maxTrailAlpha = 0.8;

// ===== Perf =====
let lastFrameTime = 0;
const targetFPS = 30;
const frameInterval = 1000 / targetFPS;
let isProcessing = false;

let performanceMode = "auto"; // 'auto' | 'performance' | 'quality'
const maxRenderTime = 33; // ~30fps

let gpuEnabled = false;

// ===== Resize =====
function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  tempCanvas.width = canvas.width;
  tempCanvas.height = canvas.height;
  accumCanvas.width = blurCanvas.width = canvas.width;
  accumCanvas.height = blurCanvas.height = canvas.height;
  draw();
}
window.addEventListener("resize", resize);
resize();

// ===== Loader (Image/Video) =====
loader.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  if (file.type.startsWith("video/")) {
    isVideo = true;
    if (video) {
      video.pause();
      video.removeEventListener("loadeddata", onVideoLoaded);
    }
    video = document.createElement("video");
    video.src = URL.createObjectURL(file);
    video.crossOrigin = "anonymous";
    video.loop = true;
    video.muted = true;
    video.playsInline = true;
    video.style.imageRendering = "pixelated";

    video.addEventListener("loadeddata", onVideoLoaded);

    function onVideoLoaded() {
      currAngle = 0;
      offsetX = offsetY = 0;
      video.play().catch((e) => console.log("Video autoplay failed:", e));

      function videoRenderLoop() {
        if (video && !video.paused && !video.ended) {
          const now = performance.now();
          if (now - lastFrameTime >= frameInterval && !isProcessing) {
            lastFrameTime = now;
            draw();
          }
          requestAnimationFrame(videoRenderLoop);
        }
      }
      videoRenderLoop();
    }
  } else if (file.type.startsWith("image/")) {
    isVideo = false;
    if (video) {
      video.pause();
      video = null;
    }
    img.src = URL.createObjectURL(file);
    img.onload = () => {
      currAngle = 0;
      offsetX = offsetY = 0;
      draw();
    };
  }
});

// ===== UI =====
function updateControls() {
  if (modeMosaic.checked) document.body.classList.add("mosaic-mode");
  else document.body.classList.remove("mosaic-mode");
}
[modeMosaic, modeHalftone, modePattern].forEach((el) =>
  el.addEventListener("change", () => {
    updateControls();
    refreshModeControls();
    draw();
  })
);

function updateLabels() {
  blockValue.textContent = (blockSlider.value / 2).toFixed(1);
  scaleValue.textContent = imgSlider.value;
  shapeValue.textContent = shapeSlider.value;
  rotationValue.textContent = (currAngle = +rotSlider.value);
  trailValue.textContent = trailSlider.value;
}
[blockSlider, imgSlider, rotSlider, trailSlider].forEach((el) =>
  el.addEventListener("input", () => {
    draw();
    updateLabels();
  })
);
shapeSlider.addEventListener("input", () => {
  draw();
  updateLabels();
});
colorBlurToggle.addEventListener("change", draw);
strokeToggle.addEventListener("change", draw);
updateControls();
updateLabels();

// ===== Dragging =====
canvas.addEventListener("mousedown", (e) => {
  isDragging = true;
  dragStartX = e.clientX;
  dragStartY = e.clientY;
  origOffsetX = offsetX;
  origOffsetY = offsetY;
  canvas.classList.add("dragging");
});
window.addEventListener("mousemove", (e) => {
  if (!isDragging) return;
  offsetX = origOffsetX + (e.clientX - dragStartX);
  offsetY = origOffsetY + (e.clientY - dragStartY);
  draw();
});
["mouseup", "mouseleave"].forEach((ev) =>
  window.addEventListener(ev, () => {
    isDragging = false;
    canvas.classList.remove("dragging");
  })
);

// ===== Utils =====
function hash2D(x, y) {
  // 타일 좌표(x,y) -> 0~1 결정적 난수
  let n = (x * 374761393) ^ (y * 668265263);
  n = (n ^ (n >>> 13)) * 1274126177;
  n = n ^ (n >>> 16);
  return (n >>> 0) / 4294967295;
}

function hexToRGB(hex) {
  if (!hex) return [102,102,102]; // 기본 회색
  hex = hex.replace(/^#/, "");
  if (hex.length === 3) hex = hex.split("").map(c => c + c).join("");
  const num = parseInt(hex, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

// ===== Patterns =====
function makePattern(type, size = 6, invert = false) {
  // CanvasPattern 대신 타일 캔버스
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d");
  g.imageSmoothingEnabled = false;

  const ink = ptInkEl?.value || "#000000";
  const bg = invert ? "#000" : "#fff";
  const fg = invert ? "#fff" : ink;

  g.fillStyle = bg;
  g.fillRect(0, 0, size, size);
  g.strokeStyle = fg;
  g.fillStyle = fg;
  g.lineWidth = Math.max(1, size * 0.08);

  switch (type) {
    case "almost_white": {
      g.beginPath();
      g.arc(size * 0.5, size * 0.5, size * 0.05, 0, Math.PI * 2);
      g.fill();
      break;
    }
    case "very_light": {
      for (let y = 0; y < size; y += 4)
        for (let x = 0; x < size; x += 4) g.fillRect(x + 1.5, y + 1.5, 0.6, 0.6);
      break;
    }
    case "light_dots": {
      for (let y = 0; y < size; y += 3)
        for (let x = 0; x < size; x += 3) {
          g.beginPath();
          g.arc(x + 1.5, y + 1.5, 0.7, 0, Math.PI * 2);
          g.fill();
        }
      break;
    }
    case "light_lines": {
      for (let x = 0; x < size; x += 3) g.fillRect(x, 0, 0.8, size);
      break;
    }
    case "medium_light": {
      for (let y = 0; y < size; y += 2.5)
        for (let x = 0; x < size; x += 2.5) {
          g.beginPath();
          g.arc(x + 1.25, y + 1.25, 0.9, 0, Math.PI * 2);
          g.fill();
        }
      break;
    }
    case "cross_light": {
      for (let y = 0; y < size; y += 4)
        for (let x = 0; x < size; x += 4) {
          g.fillRect(x + 1.3, y, 1.4, 4);
          g.fillRect(x, y + 1.3, 4, 1.4);
        }
      break;
    }
    case "medium_dots": {
      for (let y = 0; y < size; y += 2)
        for (let x = 0; x < size; x += 2) {
          g.beginPath();
          g.arc(x + 1, y + 1, 1.1, 0, Math.PI * 2);
          g.fill();
        }
      break;
    }
    case "medium_lines": {
      for (let x = 0; x < size; x += 2) g.fillRect(x, 0, 1.2, size);
      break;
    }
    case "diag_medium": {
      g.lineWidth = 1;
      for (let i = -size; i < size * 2; i += 3) {
        g.beginPath();
        g.moveTo(i, 0);
        g.lineTo(i + size, size);
        g.stroke();
      }
      break;
    }
    case "medium_dark": {
      for (let y = 0; y < size; y += 1.6)
        for (let x = 0; x < size; x += 1.6) {
          g.beginPath();
          g.arc(x + 0.8, y + 0.8, 1.15, 0, Math.PI * 2);
          g.fill();
        }
      break;
    }
    case "grid_medium": {
      g.lineWidth = 1;
      const step = size / 3;
      for (let i = 0; i <= size; i += step) {
        g.beginPath();
        g.moveTo(i, 0);
        g.lineTo(i, size);
        g.moveTo(0, i);
        g.lineTo(size, i);
        g.stroke();
      }
      break;
    }
    case "dark_lines": {
      for (let x = 0; x < size; x += 1.6) g.fillRect(x, 0, 1.3, size);
      break;
    }
    case "checker_dark": {
      const s1 = size / 4;
      for (let y = 0; y < 4; y++)
        for (let x = 0; x < 4; x++) if ((x + y) % 2 === 0) g.fillRect(x * s1, y * s1, s1, s1);
      break;
    }
    case "dense_cross": {
      for (let y = 0; y < size; y += 2.2)
        for (let x = 0; x < size; x += 2.2) {
          g.fillRect(x + 0.4, y, 1.8, 2.2);
          g.fillRect(x, y + 0.4, 2.2, 1.8);
        }
      break;
    }
    case "very_dark": {
      for (let y = 0; y < size; y += 1.2)
        for (let x = 0; x < size; x += 1.2) {
          g.beginPath();
          g.arc(x + 0.6, y + 0.6, 1, 0, Math.PI * 2);
          g.fill();
        }
      break;
    }
    case "heavy_lines": {
      for (let x = 0; x < size; x += 1.2) g.fillRect(x, 0, 1.1, size);
      break;
    }
    case "almost_black": {
      g.fillRect(0, 0, size, size);
      g.fillStyle = bg;
      for (let y = 0; y < size; y += 3)
        for (let x = 0; x < size; x += 3) {
          if ((x + y) % 6 === 0) {
            g.beginPath();
            g.arc(x + 1.5, y + 1.5, 0.5, 0, Math.PI * 2);
            g.fill();
          }
        }
      break;
    }
  }
  return c;
}

const patternsByDensity = [
  "almost_white",
  "very_light",
  "light_dots",
  "light_lines",
  "medium_light",
  "cross_light",
  "medium_dots",
  "medium_lines",
  "diag_medium",
  "medium_dark",
  "grid_medium",
  "dark_lines",
  "checker_dark",
  "dense_cross",
  "very_dark",
  "heavy_lines",
  "almost_black",
];

let patterns = [];
function generatePatterns() {
  patterns = [];
  patternsByDensity.forEach((type) => {
    patterns.push(makePattern(type, 6, false));
    patterns.push(makePattern(type, 6, true));
  });
}
generatePatterns();

// ===== Helpers =====
function getOptimizedBlockSize(originalSize, cw, ch) {
  const blockCount = (cw / originalSize) * (ch / originalSize);
  if (blockCount > 50000) return Math.max(originalSize, 8);
  if (blockCount > 25000) return Math.max(originalSize, 6);
  if (blockCount > 10000) return Math.max(originalSize, 4);
  if (isVideo) return Math.max(originalSize, 3);
  return originalSize;
}
function updatePerformanceMode(renderTime) {
  if (renderTime > maxRenderTime * 2) performanceMode = "performance";
  else if (renderTime < maxRenderTime * 0.5) performanceMode = "quality";
  else performanceMode = "auto";
}

// ▼ 추가: 현재 모드/배경색 헬퍼 + GPU 상태/제어
function getCurrentMode() {
  if (modeHalftone?.checked) return "halftone";
  if (modePattern?.checked)  return "pattern";
  return "mosaic";
}
function getBgColors() {
  const mEl = document.getElementById("bgMosaic");
  const hEl = document.getElementById("bgHalftone");
  const pEl = document.getElementById("bgPattern");
  return {
    mosaic:   mEl?.value || "#101114",
    halftone: hEl?.value || "#101114",
    pattern:  pEl?.value || "#ffffff"
  };
}
function getActiveBgColor() {
  const mode = getCurrentMode();
  return getBgColors()[mode];
}

function applyCanvasBackground() {
  const col = getActiveBgColor();
  canvas.style.background = col;
}
applyCanvasBackground();


["bgMosaic","bgHalftone","bgPattern"].forEach(id=>{
  const el = document.getElementById(id);
  if (el) el.addEventListener("input", () => { applyCanvasBackground(); window.syncGPUConfig && window.syncGPUConfig(); draw(); });
});


// 처음 로드 시 1회 적용
document.addEventListener("DOMContentLoaded", applyCanvasBackground);




function startGPU() {
  gpuEnabled = true;
  document.body.classList.add("gpu-mode");
  const cfg = {
    canvas,
    mode: getCurrentMode(),
    background: getActiveBgColor(),
  };
  if (window.WebGLApp && typeof WebGLApp.start === "function") {
    try { WebGLApp.start(cfg); } catch(e){ console.warn("WebGLApp.start error", e); }
  } else {
    const hud = document.getElementById("hud");
    if (hud) hud.textContent = "GPU mode on (fallback CPU: webgl.js not found)";
  }
  draw();
}

function stopGPU() {
  gpuEnabled = false;
  document.body.classList.remove("gpu-mode");
  if (window.WebGLApp && typeof WebGLApp.stop === "function") {
    try { WebGLApp.stop(); } catch(e){ console.warn("WebGLApp.stop error", e); }
  }
  draw();
}

window.syncGPUConfig = function syncGPUConfig() {
  if (!gpuEnabled) return;
  const cfg = {
    mode: getCurrentMode(),
    background: getActiveBgColor(),
    blockSize: +blockSlider.value / 2,
    rotation: +rotSlider.value,
    scale: +imgSlider.value,
  };
  if (window.WebGLApp) {
    try {
      if (typeof WebGLApp.update === "function")      WebGLApp.update(cfg);
      else if (typeof WebGLApp.render === "function") WebGLApp.render(cfg);
    } catch(e){ console.warn("WebGLApp.update/render error", e); }
  }
};

// GPU 토글 이벤트
if (gpuToggle) {
  gpuToggle.addEventListener("change", () => {
    if (gpuToggle.checked) startGPU();
    else stopGPU();
  });
}
// 모드/배경색/크기 변경 시 GPU에 동기화

[modeMosaic, modeHalftone, modePattern].forEach(el=>{
  if (el) el.addEventListener("change", () => window.syncGPUConfig());
});
[blockSlider, imgSlider, rotSlider].forEach(el=>{
  if (el) el.addEventListener("input", () => window.syncGPUConfig());
});



function getRotatedImageData(cw, ch) {
  tctx.clearRect(0, 0, cw, ch);
  const source = isVideo ? video : img;
  if (!source || (isVideo && video.readyState < 2) || (!isVideo && !img.complete)) {
    return new Uint8ClampedArray(cw * ch * 4);
  }
  const sw = isVideo ? video.videoWidth : img.width;
  const sh = isVideo ? video.videoHeight : img.height;
  const scale = +imgSlider.value;
  const dw = sw * scale;
  const dh = sh * scale;
  const ox = (cw - dw) / 2 + offsetX;
  const oy = (ch - dh) / 2 + offsetY;

  if (isVideo && (sw > 1920 || sh > 1080)) {
    const down = Math.min(1920 / sw, 1080 / sh);
    const sW = sw * down,
      sH = sh * down;
    tctx.drawImage(source, 0, 0, sw, sh, ox, oy, sW * scale, sH * scale);
  } else {
    tctx.drawImage(source, ox, oy, dw, dh);
  }
  return tctx.getImageData(0, 0, cw, ch).data;
}
function getRotatedCoordinates(x, y, angleDeg, cw) {
  const ang = (angleDeg * Math.PI) / 180;
  const ca = Math.cos(ang);
  const centerX = cw / 2 + offsetX;
  const invX = centerX + (x - centerX) / Math.max(ca, 1e-4);
  return { x: invX, y: y };
}

// ===== Chunked Pattern Render =====
function drawPatternChunked(data, cw, ch, step, chunks) {
  const chunkHeight = Math.ceil(ch / chunks);
  let currentChunk = 0;

  function processChunk() {
    const startY = currentChunk * chunkHeight;
    const endY = Math.min(startY + chunkHeight, ch);

    for (let y = startY; y < endY; y += step) {
      for (let x = 0; x < cw; x += step) {
        const cx = x + step / 2,
          cy = y + step / 2;
        const rot = getRotatedCoordinates(cx, cy, currAngle, cw);
        const sx = Math.floor(rot.x),
          sy = Math.floor(rot.y);
        if (sx < 0 || sx >= cw || sy < 0 || sy >= ch) continue;
        const idx = (sy * cw + sx) * 4;
        const a = data[idx + 3] / 255;
        if (a < 0.1) continue;

        // 밝기 → 밀도 → 패턴 선택
        const r = data[idx],
          g = data[idx + 1],
          b = data[idx + 2];
        let brightness = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        const gamma = 0.9,
          contrast = 1.2;
        brightness = Math.pow(brightness, gamma);
        brightness = 0.5 + (brightness - 0.5) * contrast;
        brightness = Math.min(1, Math.max(0, brightness));

        const density = 1 - brightness;
        let baseIndex = Math.round(density * (patternsByDensity.length - 1));

        const tx = Math.floor(x / step),
          ty = Math.floor(y / step);
        const h = hash2D(tx, ty);
        const variety = 0.15;
        if (h < variety) baseIndex = Math.max(0, baseIndex - 1);
        else if (h > 1 - variety) baseIndex = Math.min(patternsByDensity.length - 1, baseIndex + 1);

        const invertChance = 0.08;
        const midDark = density > 0.35 && density < 0.85;
        const invertFlag = midDark && hash2D(tx + 13, ty + 7) < invertChance ? 1 : 0;

        const finalIndex = Math.min(baseIndex * 2 + invertFlag, patterns.length - 1);

        ctx.imageSmoothingEnabled = false;
        ctx.globalCompositeOperation = "source-over";
        ctx.drawImage(patterns[finalIndex], x, y, step, step);
      }
    }

    currentChunk++;
    if (currentChunk < chunks && !isVideo) setTimeout(processChunk, 1);
  }
  processChunk();
}

// ===== Chunked Halftone (Overlap + Jitter) =====
+ function drawHalftoneChunked(data, cw, ch, step, chunks, targetCtx) {
  const chunkHeight = Math.ceil(ch / chunks);
  let currentChunk = 0;

  function processChunk() {
    const startY = currentChunk * chunkHeight;
    const endY = Math.min(startY + chunkHeight, ch);

    for (let y = startY; y < endY; y += step) {
      for (let x = 0; x < cw; x += step) {
        const cx = x + step / 2,
          cy = y + step / 2;
        const rot = getRotatedCoordinates(cx, cy, currAngle, cw);
        const sx = Math.floor(rot.x),
          sy = Math.floor(rot.y);
        if (sx < 0 || sx >= cw || sy < 0 || sy >= ch) continue;

        const idx = (sy * cw + sx) * 4;
        const a = data[idx + 3] / 255;
        if (a < 0.1) continue;

        const lum = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
        const lum01 = Math.min(1, Math.max(0, lum / 255 + densityBias));

        const rRaw = (step / 2) * (1 - lum01);
        const rMin = (step / 2) * htMinPct;
        const rMax = (step / 2) * htMaxPct;
        let r = Math.max(rMin, Math.min(rMax, rRaw));
        if (r <= 0.5) continue;

        let rOverlap = r * (1 + htOverlap);
        rOverlap = Math.min(rOverlap, step * 0.85);

        const cellX = Math.floor(x / step),
          cellY = Math.floor(y / step);
        const jx = (hash2D(cellX + 3, cellY + 11) - 0.5) * 2 * htJitterPx;
        const jy = (hash2D(cellX + 9, cellY + 21) - 0.5) * 2 * htJitterPx;

        const t = targetCtx || ctx;      // 대상 컨텍스트 선택
        t.beginPath();
        t.arc(cx + jx, cy + jy, rOverlap, 0, Math.PI * 2);
        t.fill();
      }
    }

    currentChunk++;
    if (currentChunk < chunks && !isVideo) setTimeout(processChunk, 1);
  }
  processChunk();
}

// ===== Mosaic draw =====
function drawMosaic(angleDeg, data, size, smooth, alpha, colorize, t, cw) {
  const ang = (angleDeg * Math.PI) / 180,
    ca = Math.cos(ang);
  const centerX = cw / 2 + offsetX;
  ctx.globalAlpha = alpha;
  for (let y = 0; y < canvas.height; y += size) {
    for (let x = 0; x < canvas.width; x += size) {
      const cx = x + size / 2,
        cy = y + size / 2;
      const invX = centerX + (cx - centerX) / ca;
      const sx = Math.floor(invX),
        sy = Math.floor(cy);
      if (sx < 0 || sx >= canvas.width || sy < 0 || sy >= canvas.height) continue;
      const idx = (sy * cw + sx) * 4;
      const a = data[idx + 3] / 255;
      if (a < 0.1) continue;
      ctx.fillStyle = colorize
        ? `hsla(${(t * 360) % 360},100%,50%,${a})`
        : `rgba(${data[idx]},${data[idx + 1]},${data[idx + 2]},${a})`;
      const rad = size / 2,
        corner = rad * smooth;
      ctx.beginPath();
      if (smooth >= 0.99) ctx.arc(cx, cy, rad, 0, Math.PI * 2);
      else if (smooth <= 0.01) ctx.rect(x, y, size, size);
      else {
        ctx.moveTo(x + corner, y);
        ctx.lineTo(x + size - corner, y);
        ctx.arcTo(x + size, y, x + size, y + corner, corner);
        ctx.lineTo(x + size, y + size - corner);
        ctx.arcTo(x + size, y + size, x + size - corner, y + size, corner);
        ctx.lineTo(x + corner, y + size);
        ctx.arcTo(x, y + size, x, y + size - corner, corner);
        ctx.lineTo(x, y + corner);
        ctx.arcTo(x, y, x + corner, y, corner);
      }
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

// ===== Master Draw =====
function draw() {

  if (gpuEnabled) {
    if (window.WebGLApp && typeof WebGLApp.render === "function") {
      try {
        WebGLApp.render({
          mode: getCurrentMode(),
          background: getActiveBgColor()
        });
      } catch (e) {}
    }
    return;
  }



  const source = isVideo ? video : img;
  if (!source || (isVideo && video.readyState < 2) || (!isVideo && !img.complete)) return;
  if (isVideo && isProcessing) return;
  if (isVideo) isProcessing = true;

  const startTime = performance.now();

  const cw = canvas.width,
    ch = canvas.height;
  const originalSize = +blockSlider.value / 2;
  const smooth = +shapeSlider.value;
  const trailSteps = +trailSlider.value;

  const optimizedSize = getOptimizedBlockSize(originalSize, cw, ch);

  let effectiveSize = optimizedSize;
  let effectiveTrailSteps = trailSteps;
  let samplingRate = 1;

  if (performanceMode === "performance") {
    effectiveSize = Math.max(optimizedSize, 6);
    effectiveTrailSteps = Math.min(trailSteps, 5);
    samplingRate = 2;
     } else if (isVideo) {
         effectiveSize = Math.max(optimizedSize, 1);   // 필요시 0.5로 더 낮춰도 됨
        effectiveTrailSteps = Math.min(trailSteps, 10);
      }
      

  ctx.clearRect(0, 0, cw, ch);

  // ----- Pattern Mode -----
  if (modePattern.checked) {
    ctx.fillStyle = getActiveBgColor();   
    ctx.fillRect(0, 0, cw, ch);

    const data = getRotatedImageData(cw, ch);
    const step = Math.max(1, Math.floor(effectiveSize * samplingRate * ptScale));
    ctx.imageSmoothingEnabled = false;
    ctx.globalCompositeOperation = "source-over";

    if (originalSize < 2) {
      drawPatternChunked(data, cw, ch, step, 4);
    } else {
      for (let y = 0; y < ch; y += step) {
        for (let x = 0; x < cw; x += step) {
          const cx = x + step / 2,
            cy = y + step / 2;
          const rot = getRotatedCoordinates(cx, cy, currAngle, cw);
          const sx = Math.floor(rot.x),
            sy = Math.floor(rot.y);
          if (sx < 0 || sx >= cw || sy < 0 || sy >= ch) continue;
          const idx = (sy * cw + sx) * 4;
          const a = data[idx + 3] / 255;
          if (a < 0.1) continue;

          const r = data[idx],
            g = data[idx + 1],
            b = data[idx + 2];
          let brightness = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          const gamma = 0.9,
            contrast = 1.2;
          brightness = Math.pow(brightness, gamma);
          brightness = 0.5 + (brightness - 0.5) * contrast;
          brightness = Math.min(1, Math.max(0, brightness + densityBias));

          const density = 1 - brightness;
          let baseIndex = Math.round(density * (patternsByDensity.length - 1));

          const tx = Math.floor(x / step),
            ty = Math.floor(y / step);
          const h = hash2D(tx, ty);
          const variety = ptVariety;
          if (h < variety) baseIndex = Math.max(0, baseIndex - 1);
          else if (h > 1 - variety) baseIndex = Math.min(patternsByDensity.length - 1, baseIndex + 1);

          const invertChance = ptInvert;
          const midDark = density > 0.35 && density < 0.85;
          const invertFlag = midDark && hash2D(tx + 13, ty + 7) < invertChance ? 1 : 0;

          const finalIndex = Math.min(baseIndex * 2 + invertFlag, patterns.length - 1);

          const jitterRad = (hash2D(tx + 7, ty + 5) - 0.5) * 2 * ptJitterAngle * (Math.PI / 180);
          if (ptAngle !== 0 || ptJitterAngle !== 0) {
            ctx.save();
            const cx0 = x + step / 2,
              cy0 = y + step / 2;
            ctx.translate(cx0, cy0);
            ctx.rotate((ptAngle * Math.PI) / 180 + jitterRad);
            ctx.translate(-cx0, -cy0);
            ctx.drawImage(patterns[finalIndex], x, y, step, step);
            ctx.restore();
          } else {
            ctx.drawImage(patterns[finalIndex], x, y, step, step);
          }
        }
      }
    }

    const endTime = performance.now();
    updatePerformanceMode(endTime - startTime);
    if (isVideo) isProcessing = false;
    return;
  }

  // ----- Halftone Mode -----
  if (modeHalftone.checked) {
    const data = getRotatedImageData(cw, ch);
    const step = Math.max(1, Math.floor(effectiveSize * samplingRate));

    // Blob 사용 여부
    const useBlob = htBlobPx > 0;
    const target = useBlob ? actx : ctx;

    // 초기화
    if (useBlob) {
      actx.clearRect(0, 0, cw, ch);
      actx.fillStyle = "#000"; // 누적은 검정으로 채워도 됨(나중에 회색으로 바꿔서 출력)
    } else {
      ctx.fillStyle = htInkEl?.value || "#666"; // 직접 그릴 땐 회색
    }

    if (originalSize < 2) {
      // 작은 스텝일 땐 청크 처리
      drawHalftoneChunked(data, cw, ch, step, 4);
    } else {
      for (let y = 0; y < ch; y += step) {
        for (let x = 0; x < cw; x += step) {
          const cx = x + step / 2,
            cy = y + step / 2;
          const rot = getRotatedCoordinates(cx, cy, currAngle, cw);
          const sx = Math.floor(rot.x),
            sy = Math.floor(rot.y);
          if (sx < 0 || sx >= cw || sy < 0 || sy >= ch) continue;
          const idx = (sy * cw + sx) * 4;
          const a = data[idx + 3] / 255;
          if (a < 0.1) continue;

          const lum = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
          const lum01 = Math.min(1, Math.max(0, lum / 255 + densityBias));

          const rRaw = (step / 2) * (1 - lum01);
          const rMin = (step / 2) * htMinPct;
          const rMax = (step / 2) * htMaxPct;
          let r = Math.max(rMin, Math.min(rMax, rRaw));
          if (r <= 0.5) continue;

          let rOverlap = r * (1 + htOverlap);
          rOverlap = Math.min(rOverlap, step * 0.85);

          const cellX = Math.floor(x / step),
            cellY = Math.floor(y / step);
          const jx = (hash2D(cellX + 3, cellY + 11) - 0.5) * 2 * htJitterPx;
          const jy = (hash2D(cellX + 9, cellY + 21) - 0.5) * 2 * htJitterPx;

          target.beginPath();
          target.arc(cx + jx, cy + jy, rOverlap, 0, Math.PI * 2);
          target.fill();
        }
      }
    }

    // Blob(merge) 파이프라인: 블러 후 임계값 + 회색 유지
    if (useBlob) {
      bctx.clearRect(0, 0, cw, ch);
      bctx.filter = `blur(${htBlobPx}px)`;
      bctx.drawImage(accumCanvas, 0, 0);
      bctx.filter = "none";

      const imgB = bctx.getImageData(0, 0, cw, ch);
      const d = imgB.data;
      const TH = 128; // 임계값
      const ink = htInkEl?.value || "#666666";
const [rInk, gInk, bInk] = hexToRGB(ink);

for (let i = 0; i < d.length; i += 4) {
  const on = d[i + 3] > TH;
  d[i]     = rInk;
  d[i + 1] = gInk;
  d[i + 2] = bInk;
  d[i + 3] = on ? 255 : 0;
}

ctx.putImageData(imgB, 0, 0);
}




    const endTime = performance.now();
    updatePerformanceMode(endTime - startTime);
    if (isVideo) isProcessing = false;
    return;
  }

  // ----- Mosaic + Trails -----
  const data2 = getRotatedImageData(cw, ch);

  if (originalSize < 2) {
    drawMosaic(currAngle, data2, effectiveSize, smooth, 1, false, 1, cw);
  } else {
    for (let s = 0; s < effectiveTrailSteps; s++) {
      const t = (s + 1) / (effectiveTrailSteps + 1);
      const a = currAngle * t;
      const alpha = maxTrailAlpha * (1 - t);
      drawMosaic(a, data2, effectiveSize, smooth, alpha, colorBlurToggle.checked, t, cw);
    }
    drawMosaic(currAngle, data2, effectiveSize, smooth, 1, false, 1, cw);
  }

  if (strokeToggle.checked && !isVideo && originalSize >= 2) {
    ctx.strokeStyle = "#0008";
    ctx.lineWidth = Math.max(1, effectiveSize * 0.05);
    for (let y = 0; y < ch; y += effectiveSize) {
      for (let x = 0; x < cw; x += effectiveSize) {
        ctx.beginPath();
        ctx.arc(x + effectiveSize / 2, y + effectiveSize / 2, effectiveSize / 2, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }

  const endTime2 = performance.now();
  updatePerformanceMode(endTime2 - startTime);
  if (isVideo) isProcessing = false;
}

// ===== HUD & Mode-specific controls =====
const hudEl = document.getElementById("hud");
const halftoneControls = document.getElementById("halftoneControls");
const patternControls = document.getElementById("patternControls");

// Halftone sliders
const htMinEl = document.getElementById("htMin");
const htMaxEl = document.getElementById("htMax");
const htJitterEl = document.getElementById("htJitter");
const densityBiasEl = document.getElementById("densityBias");
const htOverlapEl = document.getElementById("htOverlap");
const htBlobEl = document.getElementById("htBlob");

const htMinVal = document.getElementById("htMinVal");
const htMaxVal = document.getElementById("htMaxVal");
const htJitterVal = document.getElementById("htJitterVal");
const densityBiasVal = document.getElementById("densityBiasVal");
const htOverlapVal = document.getElementById("htOverlapVal");
const htBlobVal = document.getElementById("htBlobVal");

// Pattern sliders
const ptVarietyEl = document.getElementById("ptVariety");
const ptInvertEl = document.getElementById("ptInvert");
const ptScaleEl = document.getElementById("ptScale");
const ptAngleEl = document.getElementById("ptAngle");
const ptJitterAngleEl = document.getElementById("ptJitterAngle");
const ptBiasEl = document.getElementById("ptBias");

const ptVarietyVal = document.getElementById("ptVarietyVal");
const ptInvertVal = document.getElementById("ptInvertVal");
const ptScaleVal = document.getElementById("ptScaleVal");
const ptAngleVal = document.getElementById("ptAngleVal");
const ptJitterAngleVal = document.getElementById("ptJitterAngleVal");
const ptBiasVal = document.getElementById("ptBiasVal");

// 값 상태(필요 최소한)
let densityBias = 0; // 공통
let ptScale = 1.0; // Pattern
let htOverlap = 0; // 0~1
let htBlobPx = 0; // px (0이면 Blob 비활성)

// 모드별 컨트롤 표시
function refreshModeControls() {
  if (!halftoneControls || !patternControls) return;
  if (modeHalftone.checked) {
    halftoneControls.classList.remove("hidden");
    patternControls.classList.add("hidden");
  } else if (modePattern.checked) {
    patternControls.classList.remove("hidden");
    halftoneControls.classList.add("hidden");
  } else {
    halftoneControls.classList.add("hidden");
    patternControls.classList.add("hidden");
  }
}
[modeMosaic, modeHalftone, modePattern].forEach((el) =>
  el.addEventListener("change", () => {
    updateControls();
    refreshModeControls();
    draw();
  })
);

// 슬라이더 연결
function wireModeSpecificControls() {
  if (htMinEl) {
    htMinEl.addEventListener("input", () => {
      htMinPct = Math.min(htMaxPct, htMinEl.value / 100);
      htMinVal.textContent = htMinEl.value + "%";
      draw();
    });
    htMaxEl.addEventListener("input", () => {
      htMaxPct = Math.max(htMinPct, htMaxEl.value / 100);
      htMaxVal.textContent = htMaxEl.value + "%";
      draw();
    });
    htJitterEl.addEventListener("input", () => {
      htJitterPx = +htJitterEl.value;
      htJitterVal.textContent = htJitterEl.value;
      draw();
    });
    densityBiasEl.addEventListener("input", () => {
      densityBias = +densityBiasEl.value / 100;
      densityBiasVal.textContent = densityBias.toFixed(3);
      draw();
    });
    if (htOverlapEl) {
      htOverlapEl.addEventListener("input", () => {
        htOverlap = +htOverlapEl.value / 100;
        htOverlapVal.textContent = htOverlapEl.value + "%";
        draw();
      });
    }
    if (htBlobEl) {
      htBlobEl.addEventListener("input", () => {
        htBlobPx = +htBlobEl.value;
        if (htBlobVal) htBlobVal.textContent = htBlobPx + "px";
        draw();
      });
    }
  }

  if (ptVarietyEl) {
    ptVarietyEl.addEventListener("input", () => {
      ptVariety = +ptVarietyEl.value / 100;
      ptVarietyVal.textContent = ptVariety.toFixed(2);
      draw();
    });
    ptInvertEl.addEventListener("input", () => {
      ptInvert = +ptInvertEl.value / 100;
      ptInvertVal.textContent = ptInvert.toFixed(2);
      draw();
    });
    ptScaleEl.addEventListener("input", () => {
      ptScale = +ptScaleEl.value / 100;
      ptScaleVal.textContent = ptScale.toFixed(2) + "x";
      draw();
    });
    ptAngleEl.addEventListener("input", () => {
      ptAngle = +ptAngleEl.value;
      ptAngleVal.textContent = ptAngleEl.value;
      draw();
    });
    ptJitterAngleEl.addEventListener("input", () => {
      ptJitterAngle = +ptJitterAngleEl.value;
      ptJitterAngleVal.textContent = ptJitterAngleEl.value;
      draw();
    });
    ptBiasEl.addEventListener("input", () => {
      densityBias = +ptBiasEl.value / 100;
      ptBiasVal.textContent = densityBias.toFixed(3);
      draw();
    });
  }
}
document.addEventListener("DOMContentLoaded", () => {
  refreshModeControls();
  wireModeSpecificControls();
});

// Halftone params
let htMinPct = 0.05,
  htMaxPct = 0.95,
  htJitterPx = 0;
// Pattern params
let ptVariety = 0.15,
  ptInvert = 0.08,
  ptAngle = 0,
  ptJitterAngle = 0;

function updateHUD() {
  const hud = document.getElementById("hud");
  if (!hud) return;
  const mode = modeHalftone.checked ? "Halftone" : modePattern.checked ? "Pattern" : "Mosaic";
  hud.textContent = `${mode} | bias:${densityBias.toFixed(3)} | ptScale:${ptScale.toFixed(2)} | blob:${
    htBlobPx | 0
  }px`;
}
